(function () {
  "use strict";

  // ============ HOME PAGE: Generate Quiz ============

  const topicForm = document.getElementById("topicForm");
  const generateBtn = document.getElementById("generateBtn");
  const loadingDiv = document.getElementById("loading");

  if (topicForm) {
    topicForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      // Show loading
      loadingDiv.classList.remove("hidden");
      generateBtn.disabled = true;

      const formData = new FormData(topicForm);

      try {
        const res = await fetch("/generate", {
          method: "POST",
          body: formData,
        });

        const data = await res.json();

        if (data.success) {
          // Redirect to quiz page with questions
          window.location.href = "/quiz?data=" + encodeURIComponent(JSON.stringify(data.questions));
        } else {
          alert("Error: " + (data.message || "Failed to generate quiz."));
        }
      } catch (err) {
        alert("Network error. Please try again.");
      } finally {
        loadingDiv.classList.add("hidden");
        generateBtn.disabled = false;
      }
    });
  }

  // ============ QUIZ PAGE LOGIC ============

  const questionTextEl = document.getElementById("questionText");
  const optionsEl = document.getElementById("options");
  const nextBtn = document.getElementById("nextBtn");
  const progressFill = document.getElementById("progressFill");
  const timerBar = document.getElementById("timerBar");

  let quizQuestions = window.quizData || [];
  let currentIdx = 0;
  let userAnswers = [];
  let timer = null;
  const QUESTION_TIME = 10000; // 10 seconds per question

  if (quizQuestions.length > 0 && questionTextEl) {
    startQuiz();

    function startQuiz() {
      updateProgress();
      renderQuestion();
      startTimer();
    }

    function renderQuestion() {
      const q = quizQuestions[currentIdx];
      questionTextEl.textContent = q.question;

      optionsEl.innerHTML = "";
      q.options.forEach((opt, i) => {
        const id = `opt-${currentIdx}-${i}`;
        const letter = ["A", "B", "C", "D"][i];
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "option";
        btn.setAttribute("data-option", letter);
        btn.innerHTML = `<span class="letter">${letter}.</span> ${opt}`;
        btn.addEventListener("click", () => selectOption(btn, letter));
        optionsEl.appendChild(btn);
      });

      // Reset timer animation
      timerBar.style.animation = "none";
      void timerBar.offsetWidth; // Trigger reflow
      timerBar.style.animation = `timerShrink ${QUESTION_TIME / 1000}s linear forwards`;
    }

    function selectOption(button, letter) {
      clearTimeout(timer);
      // Disable all options
      document.querySelectorAll(".option").forEach((btn) => {
        btn.disabled = true;
      });

      // Record answer
      userAnswers[currentIdx] = letter;

      const q = quizQuestions[currentIdx];
      const key = q.answer.trim().toUpperCase()[0]; // A/B/C/D

      document.querySelectorAll(".option").forEach((btn) => {
        const opt = btn.getAttribute("data-option");
        if (opt === key) {
          btn.classList.add("correct");
        } else if (opt === letter) {
          btn.classList.add("wrong");
        }
      });

      nextBtn.classList.remove("hidden");
      nextBtn.onclick = goToNextOrResult;
    }

    function startTimer() {
      const buttons = document.querySelectorAll(".option");
      timer = setTimeout(() => {
        if (userAnswers[currentIdx] === undefined) {
          userAnswers[currentIdx] = null;
          buttons.forEach((btn) => {
            btn.disabled = true;
            if (btn.getAttribute("data-option") === quizQuestions[currentIdx].answer.trim().toUpperCase()[0]) {
              btn.classList.add("correct");
            }
          });
          
          // Instantly go to next question
          goToNextOrResult();
        }
      }, QUESTION_TIME);
    }

    function updateProgress() {
      const p = ((currentIdx + 1) / quizQuestions.length) * 100;
      progressFill.style.width = p + "%";
    }

    function goToNextOrResult() {
      clearTimeout(timer);
      currentIdx++;

      if (currentIdx < quizQuestions.length) {
        nextBtn.classList.add("hidden");
        startTimer();
        startQuiz();
      } else {
        // Calculate score
        let score = 0;
        quizQuestions.forEach((q, i) => {
          const key = q.answer.trim().toUpperCase()[0];
          if (userAnswers[i] === key) {
            score++;
          }
        });

        // Send score to result page
        const search = new URLSearchParams();
        search.set("score", score);
        search.set("total", quizQuestions.length);
        window.location.href = "/result?" + search.toString();
      }
    }
  }

  // ============ RESULT PAGE LOGIC ============

  const scoreTextEl = document.getElementById("scoreText");
  const performanceMsgEl = document.getElementById("performanceMsg");
  const restartBtn = document.getElementById("restartBtn");
  const confettiEl = document.getElementById("confetti");

  if (scoreTextEl && window.score !== undefined && window.total !== undefined) {
    const score = window.score;
    const total = window.total;
    const percentage = (score / total) * 100;

    scoreTextEl.textContent = `${score} / ${total}`;

    if (percentage >= 80) {
      performanceMsgEl.textContent = "Excellent job! 🌟";
      addConfetti();
    } else if (percentage >= 60) {
      performanceMsgEl.textContent = "Good effort! 🎯";
    } else {
      performanceMsgEl.textContent = "Try again, you can do better! 🙌";
    }

    if (restartBtn) {
      restartBtn.addEventListener("click", () => {
        window.location.href = "/";
      });
    }
  }

  // Simple confetti effect
  function addConfetti() {
    if (!confettiEl) return;

    const colors = ["#ff6b6b", "#feca57", "#48dbfb", "#1dd1a1", "#ff9ff3"];
    confettiEl.innerHTML = "";

    for (let i = 0; i < 30; i++) {
      const p = document.createElement("div");
      p.className = "confetti-piece";
      p.style.cssText = `
        position: absolute;
        width: 8px;
        height: 8px;
        background: ${colors[Math.floor(Math.random() * colors.length)]};
        border-radius: 50%;
        top: 10px;
        left: ${Math.random() * 100}%;
        animation: fall ${Math.random() * 2 + 1}s linear forwards;
      `;
      confettiEl.appendChild(p);
    }

    const style = document.createElement("style");
    style.textContent = `
      @keyframes fall {
        0% { transform: translateY(0) rotate(0deg); opacity: 1; }
        100% { transform: translateY(100px) rotate(720deg); opacity: 0; }
      }
    `;
    document.head.appendChild(style);
  }
})();