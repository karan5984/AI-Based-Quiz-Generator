import os
import json
from flask import Flask, render_template, request, jsonify, redirect, url_for
from groq import Groq
from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "super-secret-key")

# Initialize Groq client
client = Groq(api_key=os.getenv("GROQ_API_KEY"))


def call_groq(topic: str, difficulty: str, context: str = ""):
    prompt = f"""
You are an AI quiz generator. Create exactly 5 multiple‑choice questions on the topic
"{topic}" at {difficulty} difficulty level.

Return a JSON array with exactly 5 objects. Each object must look like this:

{{
  "question": "Question text",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "answer": "Option letter (A/B/C/D)"
}}

For each question, ensure:
- There are 4 options.
- Only ONE option is correct.
- The `answer` field is a single letter (A/B/C/D).
- Do NOT output any extra text outside the JSON array.
"""

    if context.strip():
        prompt += f"\nThe questions should be based on this text:\n{context}"

    try:
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            return {"success": False, "error": "API key not configured. Add GROQ_API_KEY to .env file"}
        
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=2000,
        )
        content = response.choices[0].message.content
        
        # Clean the content to extract JSON
        content = content.strip()
        if content.startswith('```json'):
            content = content[7:]
        if content.endswith('```'):
            content = content[:-3]
        content = content.strip()
        
        data = json.loads(content)
        
        # Handle both direct array and wrapped object responses
        if isinstance(data, list):
            questions = data
        elif isinstance(data, dict) and "questions" in data:
            questions = data["questions"]
        else:
            return {"success": False, "error": f"Unexpected response format: {data}"}
        
        if not isinstance(questions, list) or len(questions) == 0:
            return {"success": False, "error": "No questions returned from API"}
        
        return {"success": True, "questions": questions}
    except Exception as e:
        print(f"Groq Error: {str(e)}")
        return {"success": False, "error": f"API Error: {str(e)}"}



@app.route("/")
def index():
    return render_template("index.html")


@app.route("/test-api")
def test_api():
    """Test if the Groq API connection is working"""
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        return jsonify({"status": "error", "message": "GROQ_API_KEY not found in environment"}), 400
    
    if api_key.startswith("gsk_"):
        return jsonify({
            "status": "ok",
            "message": "API key is configured",
            "key_preview": f"{api_key[:10]}...{api_key[-5:]}"
        })
    else:
        return jsonify({
            "status": "error",
            "message": "API key format looks invalid (Groq keys should start with 'gsk_')"
        }), 400


@app.route("/generate", methods=["POST"])
def generate():
    topic = request.form.get("topic", "").strip()
    difficulty = request.form.get("difficulty", "easy")
    file = request.files.get("file")

    if not topic:
        return jsonify({"success": False, "message": "Please enter a topic."})

    context = ""
    if file and file.filename:
        try:
            content = file.read().decode("utf-8")
            context = content[:3000]  # Limit length
        except Exception as e:
            return jsonify({"success": False, "message": "Could not read file."})

    result = call_groq(topic, difficulty, context)
    if result["success"]:
        return jsonify({"success": True, "questions": result["questions"]})
    else:
        error_msg = result.get("error", "Failed to generate quiz. Please try again.")
        return jsonify({"success": False, "message": error_msg})


@app.route("/quiz")
def quiz():
    raw_data = request.args.get("data", "[]")
    try:
        quiz_data = json.loads(raw_data)
    except Exception:
        return redirect(url_for("index"))

    if not isinstance(quiz_data, list) or len(quiz_data) == 0:
        return redirect(url_for("index"))

    return render_template("quiz.html", quiz_data=quiz_data)


@app.route("/result")
def result():
    score = request.args.get("score", default=0, type=int)
    total = request.args.get("total", default=0, type=int)
    return render_template("result.html", score=score, total=total)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)